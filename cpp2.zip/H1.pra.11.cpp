#include<iostream>
using  namespace  std;
int  main()
{
        int  m;
        cin>>m;

        if(
m%2!=0
)
        {
                cout<<"even";
        }
        else
        {
                cout<<"odd";
        }
        return  0;
}
