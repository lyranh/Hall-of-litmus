#include<iostream>
#include<iomanip>
using namespace std;

int  main()
{
    double a,v,length;
    cin>>a>>v;
    length=v*v/(2*a);
    cout.precision(2);

    cout<<setiosflags(ios::fixed)<<length;
    system ("pause") ;
    return 0;
}

