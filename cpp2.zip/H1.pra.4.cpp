#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	
    float debt,rate,interests;
  
    
    cin>>debt>>rate;
    interests=debt*(rate/1200);
    
    
    cout<<fixed<<setprecision(3)<<interests<<endl;
    
    system("pause");
    
    return 0;
}
	
