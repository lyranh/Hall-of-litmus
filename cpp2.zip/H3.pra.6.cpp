#include<iostream>
using namespace std;

int main()
{
	int m,n;
	cin>>m>>n;
	int i=m;
	while(i<n)
	{
		if((i%3==0)&&(i%5!=0))
        {
        	cout<<i<<" ";
		}
		i++;
	}
	system("pause");
	return 0;
}
