#include<iostream>
#include<iomanip> 
using namespace std;

int fib(int n);
int countTimes=0;

int main()
{
	int i;
	
	for(i=1;i<=24;i++)
	{
	cout<<setw(10)<<fib(i);
	if(i%6==0)
	  cout<<endl;
	}
	cout<<"���ú�����������"<<countTimes<<endl;
	
	return 0; 
 } 
 int fib(int n)
 {
 	countTimes++;
 	
 	if(0==n||1==n)
 	   return 1;
 	else
 	   return fib(n-1)+fib(n-2);
 }

