#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;

const double pi=3.1415926;

int main()
{
	double r,h,s,v;
	cin>>r>>h;
	s=pi*r*r*2+2*pi*r*h;
	v=pi*r*r*h;
	
	cout<<fixed<<setprecision(4)<<v<<","<<s<<endl;
}
