#include<iostream>
using namespace std;
int main()
{
	char q;
	cin>>q;
	cout<<" "<<" "<<q<<" "<<" "<<endl;
	cout<<" "<<q<<q<<q<<" "<<endl;
	cout<<q<<q<<q<<q<<q;
	
	system("pause");
	return 0; 
}
