#include<iostream>
using namespace std;

int main()
{
	long int x,y,r=0;
	int i;
	cin>>x;
	y=x;
	for(i=0;y!=0;i++)
	{
		r=r*10+y%10;
		y/=10;
	}
	if(r==x)
	  cout<<x<<"yes";
	else
	  cout<<x<<"no";

	return 0;
}
