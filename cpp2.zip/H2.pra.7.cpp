#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	double a,b,c;
	cin>>a>>b>>c;
if(a+b>c&&a+c>b&&b+c>a)
	if(a*a+b*b==c*c||a*a+c*c==b*b||b*b+c*c==a*a)
	    cout<<"1";
	else
	    cout<<"0";
		
else 
    cout<<"-1"	;
	
	system("pause");
	return 0;
		 
}
