#include<iostream>
using namespace std;
extern int x,y,z;

int main()
{
	void sort();
	cin>>x>>y>>z;
//	cout<<"Before sorting:x="<<x<<",y="<<y<<",z="<<z<<endl;
	sort();
//	cout<<"After sorting:x="<<x<<",y="<<y<<",z="<<z<<endl;
     cout<<x<<" "<<y<<" "<<z;
	return 0;
	 
}
int x,y,z;
void sort()
{
	int temp;
	if(x>y)
   {
	temp=x;
	x=y;
	y=temp;
   }

	if(y>z)
   {
	temp=y;
	y=z;
	z=temp;
   }
	
	if(x>y)
   {
	temp=x;
	x=y;
	y=temp;
   } 
}
