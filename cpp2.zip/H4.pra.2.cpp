#include<iostream>
using namespace std;

int main()
{
	long factorial(int n);
	int n,i;
	long p;
	cin>>n;
	for(i=1;i<=n;i++)
	{
		p=factorial(i);
		cout<<"Factorial of"<<i<<"is"<<p<<endl;
		
	}
	return 0;
}

long factorial(int n)
{
	long k=1;
	int j;
	for(j=1;j<=n;j++)
	k=k*j;
	return k;
}
