#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	
	int i,fib[24]={1,1},sum;
	
	sum=fib[0]+fib[1];
	for(i=2;i<24;i++)
	{
		fib[i]=fib[i-1]+fib[i-2];
		sum+=fib[i];
	}
	for(i=0;i<24;i++)
	{
		cout<<setw(10)<<fib[i];
		if((i+1)%6==0)
	   cout<<endl;
    
	}
	
	cout<<setw(10)<<"sum="<<sum<<endl;
	return 0;
 }
  
 
