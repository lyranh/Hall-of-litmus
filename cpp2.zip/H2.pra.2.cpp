#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	double price1,price2,tprice1,tprice2;
	int num1,num2;
	cin>>price1>>num1;
	cin>>price2>>num2;
	
	tprice1=price1*num1;
	tprice2=price2*num2;
	
	cout<<setw(8)<<price1;
	cout<<setw(8)<<num1;
	cout<<setw(8)<<tprice1<<endl;
	
	cout<<setw(8)<<price2;
 	cout<<setw(8)<<num2;
    cout<<setw(8)<<tprice2<<endl;
    
    system("pause");
    return 0;
}




#include  <iostream>
#include  <iomanip>
using  namespace  std;

int  main()
{
        double  price1,price2;
        int  num1,num2;
double tprice1,tprice2;
cin>>price1>>num1;
	cin>>price2>>num2;
	
	tprice1=price1*num1;
	tprice2=price2*num2;
	cout.precision(2);
        cout.setf(ios::fixed);
	cout<<setw(8)<<price1;
	cout<<setw(8)<<num1;
	cout<<setw(8)<<tprice1<<endl;

	cout<<setw(8)<<price2;
 	cout<<setw(8)<<num2;
        cout<<setw(8)<<tprice2<<endl;
    
    system("pause");
    return 0;
}
