#include <iostream>
using namespace std;

int main()
{
    int a,v,length;

    cin>>a>>v;

    cout<<length=v*v/(2*a)<<endl;

    system("pause");
    return 0;


}
