#include<iostream>
using namespace std;


	double pi=3.1415;
double getArea(int r)	
	{
	
	return pi*r*r;
}

int main()
{
	double r,pi,area;
	cin>>r>>pi;
	if(pi<0)
	area=getArea(r);
	else
	area=pi*r*r;
	cout.precision(6);
	cout.setf(ios::fixed|ios::showpoint);
	cout<<area;
	return 0;
	
}


