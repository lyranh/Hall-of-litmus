#include<iostream>
#include <fstream>
#include <vector>
#include <ctime>
#include<string>
using namespace std;
struct Goodsinfo
{
    int id;
    string name;
    string unit;
    double price;
    int stock;
};
vector<Goodsinfo>goodsinfo;
void loadGoodsData() 
{
    ifstream file("good_info2.txt");
    Goodsinfo item;
    while (file>> item.id >> item.name >> item.unit >> item.price >> item.stock) 
	{
        goodsinfo.push_back(item);   
    }
    file.close();
}
void saveGoodsData() 
{
    ofstream file("good_info2.txt");
    for (Goodsinfo item:goodsinfo)
	{
        file << item.id << " " << item.name << " " << item.unit << " " << item.price << " " << item.stock << endl;
    }
    file.close();
}
void good_change1()
{
	cout<<"���������빺��Ĳ�Ʒ���:";
	int m1;
	int m2;
	cin>>m1;
	cout<<"���������빺�������:";
	cin>>m2;
	for (Goodsinfo& item:goodsinfo)
    { 
	    if(m1==item.id) 
    	{
		item.stock-=m2;
	    }
	saveGoodsData();
    }
}

void good_change2()
{
	cout<<"���������빺��Ĳ�Ʒ���: ";
	int m1;
	int m2;
	cin>>m1;
	cout<<"���������빺�������: ";
	cin>>m2;
	for (Goodsinfo& item:goodsinfo)
    { 
	    if(m1==item.id) 
    	{
		item.stock+=m2;
	    }
	saveGoodsData();
    }
}
 
int main()
{
	
	loadGoodsData(); 
	good_change2();
	
	return 0;
}
