#include<iostream>
#include<iostream>
using namespace std;
int main()
{
	int y,m;
	cin>>y>>m;
	
	if (y%4==0&&y%100!=0||y%400==0)
	cout<<"Leap year"<<",";
	else
	cout<<"Common year"<<",";
	
		if (3<=m&&m<=5)  cout<<"Spring";
		   
		if (6<=m&&m<=8) cout<<"Summer";
		    
		if (9<=m&&m<=11)  cout<<"Fall";
		    
		if (12==m||m<=2)  cout<<"Winter";
		   
	 
	
	system("pause");
	return 0;
}
