#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	float C;
	float F;
	cin>>C;
	F=C*9/5+32;
	cout<<fixed<<setprecision(1)<<F<<endl;
}
