#include<iostream>
using namespace std;
int main()
{
	int n,i,j,s=0,w=0;
	cin>>n;
	for(i=1;i<n;i++)
	  
	  for(j=1;j<i;j++)
	     s+=i;
	     
	     w+=s;
	     cout<<s<<" "<<w;
}
