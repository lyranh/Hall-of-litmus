#include <iostream>
using namespace std;
int main()
{
    int a,b,num;
    cin>>num;
    a= num%10;
    b=num/10%10;

    
    cout<<a+b<<endl;

    system("pause");
    return 0;
}
