#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int i,n;
	float t;
	float a=2,b=1,s=0;
	cin>>n;
	int temp;
	i=1;
	s=a/b;
	while(i<n)
	{
	temp=a;
	a=a+b;
	b=temp;
	t=a/b;
	s+=t; 	
	i++;
    }
	cout<<setiosflags(ios::fixed)<<setprecision(2)<<s<<endl;
	return 0;
}

