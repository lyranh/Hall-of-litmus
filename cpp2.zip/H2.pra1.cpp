#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;

int main()
{
	float x1,y1,x2,y2;
	double dist;
	cin>>x1>>y1>>x2>>y2;
	dist=sqrt(pow(x2-x1,2)+pow(y2-y1,2));
    cout.precision(6);
    cout.setf(ios::fixed);
	cout<<"d="<<dist;
	
	return 0;
}
