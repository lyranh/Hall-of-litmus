#include<iostream> 
#include<iomanip>
using namespace std;

int main()
{
	int a,b;
	cout<<"cout a and b:";
	
	cin>>a>>b;
	

	
	
	cout<<fixed<<setprecision(6)<<static_cast<double>(a)/b<<endl;
	
	system("pause");
	
	return 0;
}
