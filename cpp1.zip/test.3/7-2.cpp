#include<iostream>
#include<string>
using namespace std;
struct friends{
	string name;
	int number;
	int money;
	int send;
	int receive;
	int end; 
};

int main()

{
	int n;
	cin>>n;
	friends people[10];
	for(int i=0;i<n;i++)
	{
		cin>>people[i].name>>people[i].number>>people[i].money;
		people[i].end=people[i].send-people[i].receive;
		people[i].send=people[i].money/people[i].number;
	}
	for(int i=0;i<n;i++)
	{
		int receive=0;
		for(int j=0;i<people[i].number;i++)
		{
			receive+=
		}
		
		
	}
	
	
	
	
		}
	
	}
	
		
		
	
	
	
	system("pause");
	return 0;
}
