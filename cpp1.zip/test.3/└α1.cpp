#include<iostream>
using namespace std;
const double PI=3.14;
class circle{
public:
 //���� 
 int r;
 //��Ϊ
 double calculate()
 {
 return 2*PI*r;	
}
	
	
};



int main()
{
	//����
	circle c1;
	c1.r=10; 
	cout<<c1.calculate()<<endl;
	
 } 
