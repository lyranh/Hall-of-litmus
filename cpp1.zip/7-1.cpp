#include<iostream>
using namespace std;
int main()
{
	string name,name_ufo;
	cin>>name;
	cin>>name_ufo;
	int code=1,code_ufo=1;
	for(char c1:name)
	{
		code*=(c1-'A'+1);
	 } 
	for(char c2:name_ufo)
	{
		code_ufo*=(c2-'A'+1);
	 } 
	if((code%47)==(code_ufo%47))
	{
		cout<<"GO";
	}
	else
	    cout<<"STAY";
	system("pause");
	return 0;    
	    
	 } 
