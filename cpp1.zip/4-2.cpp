#include<iostream>
#include<iomanip>
using namespace std;

void showValue(int num);

int main()
{
	int set[]={2,8,45,78,93,43};
	
	for(int i=0;i<6;i++)
	   showValue(set[i]);
	   if((i%3)=0)
	   cout<<endl;
	   return 0;

}

void showValue(int num)
{
	
	cout<<setw(5)<<num;

}
