#include<iostream>
#include<iomanip>
using namespace std;

void showValue(int nums[],int count);
void doubleValue(int nums[],int count);

int main()
{
	int set[]={2,8,15,29,45,38,35,90};
	
	doubleValue(set,8);
	showValue(set,8);
	
	return 0;
}

void showValue(int nums[],int count)
{
	for(int index=0;index<count;index++)
	  cout<<setw(5)<<nums[index];
	  cout<<endl;
}
void doubleValue(int nums[],int count)
{
	for(int index=0;index<count;index++)
	nums[index]*=2;
}
