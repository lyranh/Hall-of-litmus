#include<iostream>
using namespace std;

int max(int x,int y)
{
	return x>y?x:y;

}
int main()
{
	int a,b;
	
	cout<<"please cout��"; 
	cin>>a>>b;
	cout<<"�ϴ�ֵ�ǣ�"<<max(a,b)<<endl;
	
	return 0; 
}
