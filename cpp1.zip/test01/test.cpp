#include<iostream>
using namespace std;
int main()
{
    cout<<"hello";
    system("pause");
    return 0;
}