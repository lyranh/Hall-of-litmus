#include<iostream> 
using namespace std;

int main()
{
    ch=touupper

    ch=ch+('A'-'a')
    cout<<ch<<endl;

    system ("pause");

    return 0;
}