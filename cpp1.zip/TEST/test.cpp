#include <iostream>
#include <windows.h>
    using namespace std;
    int main ( )
    {   
        while(true){
            cout<<"\b\\";
            Sleep(50);

            cout<<"\b-";
            Sleep(50);
            
            cout<<"\b/";
            Sleep(50);

        }

    
        system("pause");
        return 0;
    }
