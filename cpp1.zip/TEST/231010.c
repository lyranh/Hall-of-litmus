#include <iostream>
using namespace std;

int main()
{
	int a,b;		//定义两个变量	
	
	cout<<"输入变量a和b: ";
	cin>>a>>b;		/*从键盘输入a和b的值*/
	cout<<"a+b="<<a+b<<endl;
	return 0;
}