#include <iostream>
using namespace std;

int main()
{
    int a,v,length;

    cout<<"输入飞机的加速度a和起飞速度v:";
    cin>>a>>v;

    cout<<length=v*v/(2*a)<<"输出最短跑道长度："<<endl;

    system("pause");
    return 0;


}