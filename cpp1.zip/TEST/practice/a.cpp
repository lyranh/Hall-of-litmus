#include <iostream>
using namespace std;
int main()
{
    int a,b;

    cout<<"cout a and b:";
    cin>>a>>b;
    cout <<"a+b="<<a+b<<endl;

    system("pause");
    return 0;
}