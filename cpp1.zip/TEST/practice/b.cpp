#include<iostream>
#include<string>
using namespace std;
struct student 
	{
		string number;
		int grade1;
		int grade2;
		int grade3;
		int total;
	};
int main()
{
	int N;
	cin>>N;
	student stu[N];
	    for(int i=0;i<N;i++)
	    {
	    	cin>>stu[i].number>>stu[i].grade1>>stu[i].grade2;
	    	stu[i].total=0.7*(stu[i].grade1)+0.3*(stu[i].grade2);
	    
		}
		for(int i=0;i<N;i++)
		{
			if(stu[i].grade1+stu[i].grade2>140&&stu[i].total>=80)
	    	cout<<"Excellent"<<endl;
	    	else
	    	cout<<"Not excellent"<<endl;
		}
	
}