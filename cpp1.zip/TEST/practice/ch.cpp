#include<iostream>
using namespace std;
int main()
{
	int num,a,b,c;
	cin>>num;
	a=num%10;
	b=num/10%10;
	c=num/100;
	cout<<a<<b<<c;
	
	
    system("pause");
    return 0;
}