#include <iostream>
using namespace std;

int main()
{
    int y;
    cout<<"请输入年份：";
    cin>>y;
    if(y%4==0&&y%100!=0||y%400=0)
    cout<<y<<"年是闰年."<<endl;
    else
    cout<<y<<"年是闰年."<<endl;

    return 0;
}